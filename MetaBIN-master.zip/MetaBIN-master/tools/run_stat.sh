clear
python3 find_results.py --folder_dir '../logs' --folder_name 'Visualize' --start_name 'j02' --end_name 'j02' --max_only '1' --name_length '1' --bin_all '2' --num_sampling '1' --dpi '300'
python3 find_results.py --folder_dir '../logs' --folder_name 'Visualize' --start_name 'g01' --end_name 'g05' --max_only '1' --name_length '1' --bin_all '2' --num_sampling '1' --dpi '300' --except_number 3
python3 find_results.py --folder_dir '../logs' --folder_name 'Visualize' --start_name 'f01' --end_name 'f03' --max_only '1' --name_length '1' --bin_all '2' --num_sampling '1' --dpi '300'
python3 find_results.py --folder_dir '../logs' --folder_name 'Visualize' --start_name 'l04' --end_name 'l08' --max_only '1' --name_length '1' --bin_all '2' --num_sampling '1' --dpi '300' --except_number 5
python3 find_results.py --folder_dir '../logs' --folder_name 'Visualize' --start_name 'c03_old' --end_name 'c03_old' --max_only '1' --name_length '7' --bin_all '2' --num_sampling '1' --dpi '300'
python3 find_results.py --folder_dir '../logs' --folder_name 'Visualize' --start_name 'l04_old' --end_name 'l04_old' --max_only '1' --name_length '7' --bin_all '2' --num_sampling '1' --dpi '300'
python3 find_results.py --folder_dir '../logs' --folder_name 'Visualize' --start_name 'l08_old' --end_name 'l08_old' --max_only '1' --name_length '7' --bin_all '2' --num_sampling '1' --dpi '300'
clear

