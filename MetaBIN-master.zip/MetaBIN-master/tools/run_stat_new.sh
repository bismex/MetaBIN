clear
python3 find_results.py --folder_dir '../logs' --folder_name 'Final_all' --start_name 'a07' --end_name 'a07' --max_only '1' --name_length '1' --bin_all '2' --num_sampling '1' --dpi '300'
python3 find_results.py --folder_dir '../logs' --folder_name 'Final_all' --start_name 'a10' --end_name 'a10' --max_only '1' --name_length '1' --bin_all '2' --num_sampling '1' --dpi '300'
python3 find_results.py --folder_dir '../logs' --folder_name 'Final_all' --start_name 'd20' --end_name 'd20' --max_only '1' --name_length '1' --bin_all '2' --num_sampling '1' --dpi '300'
python3 find_results.py --folder_dir '../logs' --folder_name 'Final_all' --start_name 'd31' --end_name 'd31' --max_only '1' --name_length '1' --bin_all '2' --num_sampling '1' --dpi '300'
python3 find_results.py --folder_dir '../logs' --folder_name 'Final_all' --start_name 'z12' --end_name 'z17' --max_only '1' --name_length '1' --bin_all '2' --num_sampling '1' --dpi '300'
python3 find_results.py --folder_dir '../logs' --folder_name 'Final_all' --start_name 'f08' --end_name 'f10' --max_only '1' --name_length '1' --bin_all '2' --num_sampling '1' --dpi '300'
clear
	
