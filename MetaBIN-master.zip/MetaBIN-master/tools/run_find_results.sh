clear
python3 find_results.py --folder_dir '../logs' --folder_name 'Final' --start_name 'y01' --end_name 'y50' --max_only '1' --name_length '1'  
python3 find_results.py --folder_dir '../logs' --folder_name 'Final' --start_name 'y01' --end_name 'y50' --max_only '1' --name_length '1' --market '1'
python3 find_results.py --folder_dir '../logs' --folder_name 'Final' --start_name 'y01' --end_name 'y50' --max_only '1' --name_length '1' --duke '1'
#python3 find_results.py --folder_dir '../logs' --folder_name 'Final' --start_name 'mark_g01' --end_name 'mark_g02' --max_only '1' --name_length '6' --market '1'
#python3 find_results.py --folder_dir '../logs' --folder_name 'Final' --start_name 'mark_g01' --end_name 'mark_g02' --max_only '1' --name_length '6' --duke '1'
#python3 find_results.py --folder_dir '../logs' --folder_name 'Final' --start_name 'm02' --end_name 'm04' --max_only '1' --name_length '1' --except_number 3





