ln -sf ../../../../DB/REID_ALL/Market-1501-v15.09.15/ ./datasets/Market-1501-v15.09.15
ln -sf ../../../../DB/REID_ALL/DukeMTMC-reID/ ./datasets/DukeMTMC-reID
ln -sf ../../../../DB/REID_ALL/cuhk03/ ./datasets/cuhk03
ln -sf ../../../../DB/REID_ALL/cuhk02/ ./datasets/cuhk02
ln -sf ../../../../DB/REID_ALL/VIPeR/ ./datasets/viper
ln -sf ../../../../DB/REID_ALL/prid_2011/ ./datasets/prid_2011
ln -sf ../../../../DB/REID_ALL/GRID/ ./datasets/GRID
ln -sf ../../../../DB/REID_ALL/QMUL-iLIDS/ ./datasets/QMUL-iLIDS
ln -sf ../../../../DB/PERSON_SEARCH/CUHK-SYSU/ ./datasets/CUHK-SYSU
# ln -sf ../../../../DB/REID_ALL/MSMT17_V2/ ./datasets/MSMT17_V2
# ln -sf ../../../../DB/VEHICLE/VehicleID_V1.0/ ./datasets/vehicleid
# ln -sf ../../../../DB/VEHICLE/VeRi/ ./datasets/veri
# ln -sf ../../../../DB/VEHICLE/VeRi-Wild/ ./datasets/VERI-Wild
# ln -sf ../../../../DB/VEHICLE/VehicleReIDKeyPointData-master/ ./datasets/veri_keypoint


