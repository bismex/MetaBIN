from .lamb import Lamb
from .swa import SWA
from .adam import Adam
from .sgd import SGD

