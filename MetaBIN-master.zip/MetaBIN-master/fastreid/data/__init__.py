# encoding: utf-8
"""
@author:  sherlock
@contact: sherlockliao01@gmail.com
"""

from .build import build_reid_train_loader, build_reid_test_loader
