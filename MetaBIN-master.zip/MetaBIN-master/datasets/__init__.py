# encoding: utf-8
"""
@author:  seokeon
@contact: seokeon@kaist.ac.kr
"""

__version__ = "0.1.0"
