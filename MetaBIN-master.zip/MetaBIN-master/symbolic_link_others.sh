ln -sf ../MetaBIN\(logs\)/ ./logs
ln -sf ../MetaBIN\(pretrained\)/ ./pretrained
